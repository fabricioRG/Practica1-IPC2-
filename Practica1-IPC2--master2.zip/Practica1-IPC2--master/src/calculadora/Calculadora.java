package calculadora;
import calculadora.gui.CalculadoraInterfaz;
/**
 *
 * @author fabricio
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CalculadoraInterfaz ci = new CalculadoraInterfaz();
        ci.setVisible(true);
    }
    
}
